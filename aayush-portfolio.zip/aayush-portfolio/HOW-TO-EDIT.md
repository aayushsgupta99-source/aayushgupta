# How to add or edit content on your site

This is a guide for changing the text on your site — not the code, just the words.
You don't need to know how to program for any of this.

## The golden rule

Every page is a `.html` file. Open it in any plain text editor (Notepad, TextEdit,
VS Code, or even GitHub's own editor on the website). The words you see on the actual
site are sitting right there as plain text between `<tags>` — change the words, leave
the tags (the stuff in `< >` brackets) alone, and you're safe.

If you ever break something by accident, the fix is easy: undo your edit, or re-download
the last working copy I gave you and start that section again.

## Editing on GitHub directly (no download needed)

1. Go to your repo on github.com.
2. Click the file you want to change (e.g. `achievements.html`).
3. Click the pencil icon (top right of the file view) to edit.
4. Make your change.
5. Scroll down, add a short message like "update achievements", click **Commit changes**.
6. Wait a minute, then hard-refresh your live site to see it.

## Where to add new things

**A new achievement** → open `achievements.html`. Near the bottom you'll find an HTML
comment (text between `<!--` and `-->`) with a ready-made template. Copy the card
pattern shown there, paste it above the comment, and fill in your own text.

**A new venture/project** → same idea, in `ventures.html`.

**A new "Now" bullet point** → open `now.html`, find the list, copy the one-line
pattern shown in the comment near the bottom of the list, and add your line.

**Your "Off duty" interests** → open `about.html`, find the section with the dashed
border that says "Add a few personal details here" — replace that whole block with
your own paragraph or list.

**Contact links (LinkedIn, Instagram, resume)** → open `contact.html`, find the
commented-out block near the bottom of the `row-list` — copy the pattern for a `row`,
uncomment it (delete the `<!--` and `-->` around it), and fill in your link.

**Colors or fonts everywhere** → open `css/style.css`, the very top has a list of
colors and font names — change those and the whole site updates.

## Things to leave alone

- Anything inside `<script>` tags or the `.js` files — that's what runs the animation
  and menu.
- Class names like `class="card"` or `class="tag"` — these control the styling. Don't
  rename them unless you're also changing `style.css` to match.
- The files `.nojekyll`, `404.html`, `css/style.css` structure, `js/hero.js`,
  `js/main.js` — these should stay exactly where they are, in `css/` and `js/`
  subfolders next to the `.html` files.

## If something looks broken after an edit

The single most common cause is a missing closing tag — e.g. you deleted `</p>` by
accident while editing a paragraph. Compare your edit against the template comment
it came from, character by character, and check you have the same number of opening
`<...>` and closing `</...>` tags.

If you get stuck, paste me the section you edited and what it looks like now — I can
spot the issue quickly.
